from .main22 import x
print(x)
