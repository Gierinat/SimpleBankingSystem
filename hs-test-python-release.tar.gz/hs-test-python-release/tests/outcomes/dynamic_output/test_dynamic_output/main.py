print('1')
print('2')
line_3 = input()
if line_3 != '3':
    0/0
print('5')
line_4 = input()
if line_4 != '4':
    0/0
print('6')
line_7 = input()
if line_7 != '7':
    0/0
line_8 = input()
if line_8 != '8':
    0/0
