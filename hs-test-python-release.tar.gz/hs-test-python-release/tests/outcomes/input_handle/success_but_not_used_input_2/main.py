print('HELLO')
print(input())
print(input())
