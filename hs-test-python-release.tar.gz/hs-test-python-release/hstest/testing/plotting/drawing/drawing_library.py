from __future__ import annotations


class DrawingLibrary:
    matplotlib = "matplotlib"
    pandas = "pandas"
    seaborn = "seaborn"
