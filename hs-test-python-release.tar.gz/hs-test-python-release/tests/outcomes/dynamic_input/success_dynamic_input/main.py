print('Hello')
line = input()
if line == '1':
    print(input())
else:
    print(line)
