for i in range(251):
    print(f"A {i} line")
