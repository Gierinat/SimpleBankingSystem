while True:
    for i in range(25):
        print("Line", i)
