print("1\u00a02 3", end='')
