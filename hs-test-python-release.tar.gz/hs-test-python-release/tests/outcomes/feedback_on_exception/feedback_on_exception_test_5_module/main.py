raise ZeroDivisionError()
