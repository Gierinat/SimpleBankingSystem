import random

while True:
    print("Long Line Long Line Long Line", random.random())
