print('Hello World')
print(1 / 0)
