from main2 import x
print(x)
