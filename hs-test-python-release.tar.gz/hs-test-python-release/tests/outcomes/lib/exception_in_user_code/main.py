print(123)
print(0 / 0)
