print(input())
