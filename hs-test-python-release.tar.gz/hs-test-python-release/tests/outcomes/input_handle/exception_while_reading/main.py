def get():
    return int(input())


def get_num():
    return get()


def get_line():
    return get_num()


print(get_line())
