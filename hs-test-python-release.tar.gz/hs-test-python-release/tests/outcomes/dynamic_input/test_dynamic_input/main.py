print(input() + '0000')
print(input() + '1111')
print(input() + '2222')
