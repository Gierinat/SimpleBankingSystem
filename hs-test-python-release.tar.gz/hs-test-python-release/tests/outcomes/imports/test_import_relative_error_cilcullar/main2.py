from .main import y
x = 1038
print(y)
