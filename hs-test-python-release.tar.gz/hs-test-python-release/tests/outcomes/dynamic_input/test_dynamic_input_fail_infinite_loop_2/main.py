while True:
    try:
        print(input())
    except Exception:
        pass
