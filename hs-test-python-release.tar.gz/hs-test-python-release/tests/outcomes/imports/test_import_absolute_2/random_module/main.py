import main2
print(main2.x)
