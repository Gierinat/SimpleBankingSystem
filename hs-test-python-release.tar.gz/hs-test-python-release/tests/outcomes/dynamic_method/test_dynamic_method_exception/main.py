print("Server started!")
print("S1: " + input())
print(0/0)
print("S2: " + input())
