from in1.in2.main2 import x
print(x)
