import in1.in2.main2 as m
import in1.file as f
print(m.x + f.y)
