from .main2 import x
y = 5
print(x)
