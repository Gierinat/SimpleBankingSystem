print('Hello!')
