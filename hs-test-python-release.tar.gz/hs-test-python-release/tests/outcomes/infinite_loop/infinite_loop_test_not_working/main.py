for i in range(1000):
    print("Line")
