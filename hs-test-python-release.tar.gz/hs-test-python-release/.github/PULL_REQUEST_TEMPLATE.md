Task: [#HSPC-](https://vyahhi.myjetbrains.com/youtrack/issue/HSPC-)

**Reviewers**
- [ ] @

**Description**
