import main2
print(main2.x)

if __name__ == '__main__':
    print()
